import{r as i}from"./index-DAn9j-1I.js";const t=i("PushNotifications",{});export{t as PushNotifications};
