import{r as i}from"./index-CfB9bdaZ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
