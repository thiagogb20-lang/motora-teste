import{r as i}from"./index-CeDzXofK.js";const t=i("PushNotifications",{});export{t as PushNotifications};
