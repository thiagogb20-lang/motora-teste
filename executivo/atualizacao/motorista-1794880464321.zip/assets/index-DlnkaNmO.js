import{r as i}from"./index-B6u9Qhsv.js";const t=i("PushNotifications",{});export{t as PushNotifications};
