import{r as i}from"./index-BujjcP4F.js";const t=i("PushNotifications",{});export{t as PushNotifications};
