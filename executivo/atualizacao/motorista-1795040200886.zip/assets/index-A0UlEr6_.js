import{r as i}from"./index-bIWpIrSO.js";const t=i("PushNotifications",{});export{t as PushNotifications};
