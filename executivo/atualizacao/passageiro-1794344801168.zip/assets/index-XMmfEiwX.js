import{r as i}from"./index-Cpj7lQpc.js";const t=i("PushNotifications",{});export{t as PushNotifications};
