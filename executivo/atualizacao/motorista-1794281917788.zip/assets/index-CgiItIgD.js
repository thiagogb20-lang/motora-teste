import{r as i}from"./index-BcP7-Hwa.js";const t=i("PushNotifications",{});export{t as PushNotifications};
