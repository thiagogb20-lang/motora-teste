import{r as i}from"./index-C16HHnwf.js";const t=i("PushNotifications",{});export{t as PushNotifications};
