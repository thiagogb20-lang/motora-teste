import{r as i}from"./index-Cp_HgUQk.js";const t=i("PushNotifications",{});export{t as PushNotifications};
