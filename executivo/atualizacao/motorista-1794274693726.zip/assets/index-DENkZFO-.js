import{r as i}from"./index-BOwhIISb.js";const t=i("PushNotifications",{});export{t as PushNotifications};
