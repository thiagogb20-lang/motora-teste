import{r as i}from"./index-fO2cvt0-.js";const t=i("PushNotifications",{});export{t as PushNotifications};
