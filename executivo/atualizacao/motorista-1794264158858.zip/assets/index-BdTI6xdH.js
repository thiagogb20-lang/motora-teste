import{r as i}from"./index-DKDcjI7K.js";const t=i("PushNotifications",{});export{t as PushNotifications};
