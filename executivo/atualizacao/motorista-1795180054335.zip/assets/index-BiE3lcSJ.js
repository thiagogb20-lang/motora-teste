import{r as i}from"./index-ErAAcB42.js";const t=i("PushNotifications",{});export{t as PushNotifications};
