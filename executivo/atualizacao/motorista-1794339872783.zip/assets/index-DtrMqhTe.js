import{r as i}from"./index-DcVvDrh3.js";const t=i("PushNotifications",{});export{t as PushNotifications};
