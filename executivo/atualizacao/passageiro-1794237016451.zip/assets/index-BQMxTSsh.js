import{r as i}from"./index-BG1wLppg.js";const t=i("PushNotifications",{});export{t as PushNotifications};
