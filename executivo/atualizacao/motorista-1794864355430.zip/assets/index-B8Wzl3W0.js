import{r as i}from"./index-DlasnLfn.js";const t=i("PushNotifications",{});export{t as PushNotifications};
