import{r as i}from"./index-CSd2PLvp.js";const t=i("PushNotifications",{});export{t as PushNotifications};
