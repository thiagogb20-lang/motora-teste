import{r as i}from"./index-GKS-ZTtI.js";const t=i("PushNotifications",{});export{t as PushNotifications};
