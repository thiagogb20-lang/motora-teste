import{r as i}from"./index-BTAl4Xxf.js";const t=i("PushNotifications",{});export{t as PushNotifications};
