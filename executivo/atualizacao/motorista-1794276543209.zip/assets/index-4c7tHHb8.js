import{r as i}from"./index-CY2UUBhR.js";const t=i("PushNotifications",{});export{t as PushNotifications};
