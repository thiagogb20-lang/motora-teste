import{r as i}from"./index-CCo_u1ux.js";const t=i("PushNotifications",{});export{t as PushNotifications};
