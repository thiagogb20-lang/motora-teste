import{r as i}from"./index-hDLyNr0h.js";const t=i("PushNotifications",{});export{t as PushNotifications};
