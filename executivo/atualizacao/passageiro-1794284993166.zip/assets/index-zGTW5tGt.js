import{r as i}from"./index-CFGCBYdt.js";const t=i("PushNotifications",{});export{t as PushNotifications};
