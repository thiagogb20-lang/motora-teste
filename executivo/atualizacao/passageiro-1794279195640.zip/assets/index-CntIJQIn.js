import{r as i}from"./index-ckGq63Tc.js";const t=i("PushNotifications",{});export{t as PushNotifications};
