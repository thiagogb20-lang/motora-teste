import{r as i}from"./index-CXVHaFQD.js";const t=i("PushNotifications",{});export{t as PushNotifications};
