import{r as i}from"./index-jKo5UDne.js";const t=i("PushNotifications",{});export{t as PushNotifications};
