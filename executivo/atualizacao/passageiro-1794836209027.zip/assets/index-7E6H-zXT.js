import{r as i}from"./index-CenAJ5ZD.js";const t=i("PushNotifications",{});export{t as PushNotifications};
