import{r as i}from"./index-CUplYfqc.js";const t=i("PushNotifications",{});export{t as PushNotifications};
