import{r as i}from"./index-Uwt8zQaV.js";const t=i("PushNotifications",{});export{t as PushNotifications};
