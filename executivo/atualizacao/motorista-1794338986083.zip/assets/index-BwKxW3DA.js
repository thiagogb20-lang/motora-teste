import{r as i}from"./index-CTr-7x1T.js";const t=i("PushNotifications",{});export{t as PushNotifications};
