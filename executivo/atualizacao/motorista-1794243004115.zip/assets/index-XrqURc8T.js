import{r as i}from"./index-Ddd-q1N0.js";const t=i("PushNotifications",{});export{t as PushNotifications};
