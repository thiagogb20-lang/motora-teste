import{r as i}from"./index-CubpT0pp.js";const t=i("PushNotifications",{});export{t as PushNotifications};
