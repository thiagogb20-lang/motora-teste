import{r as i}from"./index-C5PFDf7g.js";const t=i("PushNotifications",{});export{t as PushNotifications};
