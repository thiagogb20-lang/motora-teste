import{r as i}from"./index-DOWAl8WH.js";const t=i("PushNotifications",{});export{t as PushNotifications};
