import{r as i}from"./index-Dg7zMvTb.js";const t=i("PushNotifications",{});export{t as PushNotifications};
