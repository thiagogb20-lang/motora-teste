import{r as i}from"./index-DWbFOw0Q.js";const t=i("PushNotifications",{});export{t as PushNotifications};
