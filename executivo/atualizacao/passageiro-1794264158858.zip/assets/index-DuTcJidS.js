import{r as i}from"./index-B_Y9vNs5.js";const t=i("PushNotifications",{});export{t as PushNotifications};
