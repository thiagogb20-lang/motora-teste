import{r as i}from"./index-BXmhtEq4.js";const t=i("PushNotifications",{});export{t as PushNotifications};
