import{r as i}from"./index-De7WT-ih.js";const t=i("PushNotifications",{});export{t as PushNotifications};
