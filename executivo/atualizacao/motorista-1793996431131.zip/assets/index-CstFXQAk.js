import{r as i}from"./index-BCK60ffg.js";const t=i("PushNotifications",{});export{t as PushNotifications};
