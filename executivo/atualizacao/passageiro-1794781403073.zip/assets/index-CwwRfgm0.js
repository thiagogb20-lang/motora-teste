import{r as i}from"./index-5kYYcSLs.js";const t=i("PushNotifications",{});export{t as PushNotifications};
