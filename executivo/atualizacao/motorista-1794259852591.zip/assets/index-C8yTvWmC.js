import{r as i}from"./index-B7XDKKgd.js";const t=i("PushNotifications",{});export{t as PushNotifications};
