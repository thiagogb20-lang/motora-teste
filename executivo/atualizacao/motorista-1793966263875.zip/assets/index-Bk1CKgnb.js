import{r as i}from"./index-ChetElFm.js";const t=i("PushNotifications",{});export{t as PushNotifications};
