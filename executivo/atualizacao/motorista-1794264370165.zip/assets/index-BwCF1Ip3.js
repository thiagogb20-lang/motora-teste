import{r as i}from"./index-Dz3KMrRk.js";const t=i("PushNotifications",{});export{t as PushNotifications};
