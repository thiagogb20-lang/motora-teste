import{r as i}from"./index-ByiFBCtf.js";const t=i("PushNotifications",{});export{t as PushNotifications};
