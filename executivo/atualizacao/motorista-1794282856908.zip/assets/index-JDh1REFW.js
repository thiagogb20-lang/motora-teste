import{r as i}from"./index-D89u9Csa.js";const t=i("PushNotifications",{});export{t as PushNotifications};
