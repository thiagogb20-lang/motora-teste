import{r as i}from"./index-mBTwNn1y.js";const t=i("PushNotifications",{});export{t as PushNotifications};
