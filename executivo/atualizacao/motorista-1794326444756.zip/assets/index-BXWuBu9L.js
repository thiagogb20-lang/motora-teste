import{r as i}from"./index-BK0WsshL.js";const t=i("PushNotifications",{});export{t as PushNotifications};
