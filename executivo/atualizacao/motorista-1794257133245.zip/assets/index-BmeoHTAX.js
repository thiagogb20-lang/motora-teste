import{r as i}from"./index-B3LkCQdf.js";const t=i("PushNotifications",{});export{t as PushNotifications};
