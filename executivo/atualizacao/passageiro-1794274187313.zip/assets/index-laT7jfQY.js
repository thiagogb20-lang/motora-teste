import{r as i}from"./index-D-xl9mIW.js";const t=i("PushNotifications",{});export{t as PushNotifications};
