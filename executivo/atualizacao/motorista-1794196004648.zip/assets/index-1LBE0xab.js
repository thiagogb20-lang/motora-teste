import{r as i}from"./index-CF9DgKVQ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
