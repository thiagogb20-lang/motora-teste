import{r as i}from"./index-NyIc2tsc.js";const t=i("PushNotifications",{});export{t as PushNotifications};
