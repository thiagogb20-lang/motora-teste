import{r as i}from"./index-w-5G0-LB.js";const t=i("PushNotifications",{});export{t as PushNotifications};
