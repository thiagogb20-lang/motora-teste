import{r as i}from"./index-BWyJPxF5.js";const t=i("PushNotifications",{});export{t as PushNotifications};
