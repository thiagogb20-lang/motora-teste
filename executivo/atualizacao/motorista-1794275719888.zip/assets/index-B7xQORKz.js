import{r as i}from"./index-DLj1Lmf5.js";const t=i("PushNotifications",{});export{t as PushNotifications};
