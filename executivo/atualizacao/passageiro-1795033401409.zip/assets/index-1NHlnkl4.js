import{r as i}from"./index-DyOjLqN-.js";const t=i("PushNotifications",{});export{t as PushNotifications};
