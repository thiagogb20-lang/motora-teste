import{r as i}from"./index-w2wliPPl.js";const t=i("PushNotifications",{});export{t as PushNotifications};
