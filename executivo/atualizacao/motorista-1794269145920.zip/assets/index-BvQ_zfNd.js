import{r as i}from"./index-Dp-gyB3w.js";const t=i("PushNotifications",{});export{t as PushNotifications};
