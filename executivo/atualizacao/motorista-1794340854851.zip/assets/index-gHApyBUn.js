import{r as i}from"./index-CTSZdZVn.js";const t=i("PushNotifications",{});export{t as PushNotifications};
