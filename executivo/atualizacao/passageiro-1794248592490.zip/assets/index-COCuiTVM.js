import{r as i}from"./index-C5q8bPZA.js";const t=i("PushNotifications",{});export{t as PushNotifications};
