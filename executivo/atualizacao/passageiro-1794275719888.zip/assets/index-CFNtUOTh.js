import{r as i}from"./index-C1Wqy0eJ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
