import{r as i}from"./index-02VxXXoG.js";const t=i("PushNotifications",{});export{t as PushNotifications};
