import{r as i}from"./index-CPJBu7eV.js";const t=i("PushNotifications",{});export{t as PushNotifications};
