import{r as i}from"./index-CQeFupTd.js";const t=i("PushNotifications",{});export{t as PushNotifications};
