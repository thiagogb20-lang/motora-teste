import{r as i}from"./index-JGVhbnrJ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
