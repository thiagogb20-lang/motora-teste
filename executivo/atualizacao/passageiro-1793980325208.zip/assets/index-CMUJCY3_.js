import{r as i}from"./index-BUmwVdeq.js";const t=i("PushNotifications",{});export{t as PushNotifications};
