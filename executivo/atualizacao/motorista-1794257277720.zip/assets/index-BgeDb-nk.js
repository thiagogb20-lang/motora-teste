import{r as i}from"./index-Dz12U53a.js";const t=i("PushNotifications",{});export{t as PushNotifications};
