import{r as i}from"./index-_z6K6IzV.js";const t=i("PushNotifications",{});export{t as PushNotifications};
