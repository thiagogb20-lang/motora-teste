import{r as i}from"./index-BpS62YVr.js";const t=i("PushNotifications",{});export{t as PushNotifications};
