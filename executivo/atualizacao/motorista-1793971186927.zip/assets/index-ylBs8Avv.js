import{r as i}from"./index-kUuZGHBy.js";const t=i("PushNotifications",{});export{t as PushNotifications};
