import{r as i}from"./index-0RyRO7YB.js";const t=i("PushNotifications",{});export{t as PushNotifications};
