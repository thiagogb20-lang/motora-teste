import{r as i}from"./index-CW0J6759.js";const t=i("PushNotifications",{});export{t as PushNotifications};
