import{r as i}from"./index-CkIy8l65.js";const t=i("PushNotifications",{});export{t as PushNotifications};
