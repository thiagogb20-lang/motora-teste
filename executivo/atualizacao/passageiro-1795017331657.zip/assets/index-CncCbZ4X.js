import{r as i}from"./index-Cujw9dt4.js";const t=i("PushNotifications",{});export{t as PushNotifications};
