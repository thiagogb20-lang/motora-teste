import{r as i}from"./index-CGWeXrMV.js";const t=i("PushNotifications",{});export{t as PushNotifications};
