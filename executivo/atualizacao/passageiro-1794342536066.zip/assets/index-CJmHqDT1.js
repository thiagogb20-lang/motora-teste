import{r as i}from"./index-DaeIn8L4.js";const t=i("PushNotifications",{});export{t as PushNotifications};
