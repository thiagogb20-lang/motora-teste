import{r as i}from"./index-DmkztL5o.js";const t=i("PushNotifications",{});export{t as PushNotifications};
