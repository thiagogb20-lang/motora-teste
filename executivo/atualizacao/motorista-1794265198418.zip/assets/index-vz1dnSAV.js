import{r as i}from"./index-BFbGh_20.js";const t=i("PushNotifications",{});export{t as PushNotifications};
