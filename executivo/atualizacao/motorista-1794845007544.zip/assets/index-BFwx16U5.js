import{r as i}from"./index-Cn9csk6z.js";const t=i("PushNotifications",{});export{t as PushNotifications};
