import{r as i}from"./index-D246yEJi.js";const t=i("PushNotifications",{});export{t as PushNotifications};
