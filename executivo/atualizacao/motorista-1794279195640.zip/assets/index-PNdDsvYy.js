import{r as i}from"./index-CTpcMmVT.js";const t=i("PushNotifications",{});export{t as PushNotifications};
