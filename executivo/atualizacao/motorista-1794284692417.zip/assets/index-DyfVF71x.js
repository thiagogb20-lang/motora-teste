import{r as i}from"./index-Bh0MvO-n.js";const t=i("PushNotifications",{});export{t as PushNotifications};
