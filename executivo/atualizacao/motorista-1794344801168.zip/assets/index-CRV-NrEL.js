import{r as i}from"./index-BjLyRn-w.js";const t=i("PushNotifications",{});export{t as PushNotifications};
