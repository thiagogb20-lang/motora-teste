import{r as i}from"./index-HbZcW_fQ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
