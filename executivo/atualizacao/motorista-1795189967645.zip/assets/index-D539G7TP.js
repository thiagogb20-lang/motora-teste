import{r as i}from"./index-q_wCPd1f.js";const t=i("PushNotifications",{});export{t as PushNotifications};
