import{r as i}from"./index-B7VaB2bL.js";const t=i("PushNotifications",{});export{t as PushNotifications};
