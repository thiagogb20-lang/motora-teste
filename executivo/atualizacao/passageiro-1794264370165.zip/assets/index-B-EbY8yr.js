import{r as i}from"./index-DtaIf-8p.js";const t=i("PushNotifications",{});export{t as PushNotifications};
