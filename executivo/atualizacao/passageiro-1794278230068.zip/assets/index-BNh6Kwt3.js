import{r as i}from"./index-BGUyounv.js";const t=i("PushNotifications",{});export{t as PushNotifications};
