import{r as i}from"./index-j9rI86gJ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
