import{r as i}from"./index-CRqGfX5a.js";const t=i("PushNotifications",{});export{t as PushNotifications};
