import{r as i}from"./index-D8p6Myc1.js";const t=i("PushNotifications",{});export{t as PushNotifications};
