import{r as i}from"./index-rv78520R.js";const t=i("PushNotifications",{});export{t as PushNotifications};
