import{r as i}from"./index-vImpkGHK.js";const t=i("PushNotifications",{});export{t as PushNotifications};
