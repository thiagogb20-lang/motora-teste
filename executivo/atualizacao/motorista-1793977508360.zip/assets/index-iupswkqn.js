import{r as i}from"./index-D8sqdWhx.js";const t=i("PushNotifications",{});export{t as PushNotifications};
