import{r as i}from"./index-DtN5o2KJ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
