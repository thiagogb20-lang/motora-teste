import{r as i}from"./index-duieTGKJ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
