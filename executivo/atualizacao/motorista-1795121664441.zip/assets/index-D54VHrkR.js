import{r as i}from"./index-mRg-Q34X.js";const t=i("PushNotifications",{});export{t as PushNotifications};
