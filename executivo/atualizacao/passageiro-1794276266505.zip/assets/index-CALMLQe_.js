import{r as i}from"./index-CJaMVpnZ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
