import{r as i}from"./index-BOgTDFZ6.js";const t=i("PushNotifications",{});export{t as PushNotifications};
