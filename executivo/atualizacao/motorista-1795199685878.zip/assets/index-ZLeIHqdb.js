import{r as i}from"./index-CVOsBNNE.js";const t=i("PushNotifications",{});export{t as PushNotifications};
