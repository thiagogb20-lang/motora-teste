import{r as i}from"./index-DTJ0nZNm.js";const t=i("PushNotifications",{});export{t as PushNotifications};
