import{r as i}from"./index-CNMaJkP5.js";const t=i("PushNotifications",{});export{t as PushNotifications};
