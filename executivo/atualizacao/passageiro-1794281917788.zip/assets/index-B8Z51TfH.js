import{r as i}from"./index-BDkQSxri.js";const t=i("PushNotifications",{});export{t as PushNotifications};
