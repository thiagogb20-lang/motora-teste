import{r as i}from"./index-C4JU08Pf.js";const t=i("PushNotifications",{});export{t as PushNotifications};
