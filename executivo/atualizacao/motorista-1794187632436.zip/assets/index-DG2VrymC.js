import{r as i}from"./index-Dt6TCQlH.js";const t=i("PushNotifications",{});export{t as PushNotifications};
