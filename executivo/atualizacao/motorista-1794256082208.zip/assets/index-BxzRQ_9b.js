import{r as i}from"./index-BuH-a-M2.js";const t=i("PushNotifications",{});export{t as PushNotifications};
