import{r as i}from"./index-BlGuvxgh.js";const t=i("PushNotifications",{});export{t as PushNotifications};
