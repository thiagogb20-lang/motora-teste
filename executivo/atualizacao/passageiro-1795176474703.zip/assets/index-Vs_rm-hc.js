import{r as i}from"./index-CZtBuKZM.js";const t=i("PushNotifications",{});export{t as PushNotifications};
