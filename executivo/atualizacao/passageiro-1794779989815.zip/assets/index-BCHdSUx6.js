import{r as i}from"./index-B2ZICLnQ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
