import{r as i}from"./index-BCk6VxXF.js";const t=i("PushNotifications",{});export{t as PushNotifications};
