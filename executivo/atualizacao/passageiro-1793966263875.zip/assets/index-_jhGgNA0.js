import{r as i}from"./index-Cst8AVUH.js";const t=i("PushNotifications",{});export{t as PushNotifications};
