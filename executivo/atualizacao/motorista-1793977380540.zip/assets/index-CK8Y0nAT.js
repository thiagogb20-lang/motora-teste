import{r as i}from"./index-NK_jsJyb.js";const t=i("PushNotifications",{});export{t as PushNotifications};
