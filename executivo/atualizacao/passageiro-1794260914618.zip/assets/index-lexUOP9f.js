import{r as i}from"./index-SsBi6RzD.js";const t=i("PushNotifications",{});export{t as PushNotifications};
