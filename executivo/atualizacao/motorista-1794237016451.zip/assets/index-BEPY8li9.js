import{r as i}from"./index-DXhsYGgr.js";const t=i("PushNotifications",{});export{t as PushNotifications};
