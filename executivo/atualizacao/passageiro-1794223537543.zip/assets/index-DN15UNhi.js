import{r as i}from"./index-CP4Pa8r8.js";const t=i("PushNotifications",{});export{t as PushNotifications};
