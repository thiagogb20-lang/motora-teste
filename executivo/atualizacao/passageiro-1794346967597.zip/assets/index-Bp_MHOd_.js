import{r as i}from"./index-CTAbwa9D.js";const t=i("PushNotifications",{});export{t as PushNotifications};
