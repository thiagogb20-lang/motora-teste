import{r as i}from"./index-DVIG_gve.js";const t=i("PushNotifications",{});export{t as PushNotifications};
