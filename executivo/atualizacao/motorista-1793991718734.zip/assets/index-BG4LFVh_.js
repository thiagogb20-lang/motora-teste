import{r as i}from"./index-CL-z-7oO.js";const t=i("PushNotifications",{});export{t as PushNotifications};
