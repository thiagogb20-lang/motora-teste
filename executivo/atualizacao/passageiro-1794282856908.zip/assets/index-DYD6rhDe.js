import{r as i}from"./index-Ck9CEIXE.js";const t=i("PushNotifications",{});export{t as PushNotifications};
