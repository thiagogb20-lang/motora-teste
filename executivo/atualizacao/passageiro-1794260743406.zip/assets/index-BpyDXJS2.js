import{r as i}from"./index-DspLRGs8.js";const t=i("PushNotifications",{});export{t as PushNotifications};
