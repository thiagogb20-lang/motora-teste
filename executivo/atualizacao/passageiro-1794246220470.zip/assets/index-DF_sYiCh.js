import{r as i}from"./index-B0p8A2y5.js";const t=i("PushNotifications",{});export{t as PushNotifications};
