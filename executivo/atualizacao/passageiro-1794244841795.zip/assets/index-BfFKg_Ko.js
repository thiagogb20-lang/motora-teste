import{r as i}from"./index-OQqmbEmm.js";const t=i("PushNotifications",{});export{t as PushNotifications};
