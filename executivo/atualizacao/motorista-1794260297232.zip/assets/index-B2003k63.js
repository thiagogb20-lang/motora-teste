import{r as i}from"./index-BYIIybPU.js";const t=i("PushNotifications",{});export{t as PushNotifications};
