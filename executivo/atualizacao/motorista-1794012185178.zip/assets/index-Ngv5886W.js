import{r as i}from"./index-56ooUpjo.js";const t=i("PushNotifications",{});export{t as PushNotifications};
