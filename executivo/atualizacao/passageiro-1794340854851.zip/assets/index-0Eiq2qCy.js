import{r as i}from"./index-CgLjtoZJ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
