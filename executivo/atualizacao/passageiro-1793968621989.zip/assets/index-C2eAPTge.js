import{r as i}from"./index-CJgu10nx.js";const t=i("PushNotifications",{});export{t as PushNotifications};
