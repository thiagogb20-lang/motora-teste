import{r as i}from"./index-BHwDDJre.js";const t=i("PushNotifications",{});export{t as PushNotifications};
