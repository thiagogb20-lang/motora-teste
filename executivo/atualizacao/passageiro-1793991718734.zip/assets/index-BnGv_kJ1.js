import{r as i}from"./index-BlbMX5BB.js";const t=i("PushNotifications",{});export{t as PushNotifications};
