import{r as i}from"./index-Bp8ph5Dk.js";const t=i("PushNotifications",{});export{t as PushNotifications};
