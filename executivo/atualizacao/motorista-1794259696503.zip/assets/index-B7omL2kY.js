import{r as i}from"./index-Cr1fdMHL.js";const t=i("PushNotifications",{});export{t as PushNotifications};
