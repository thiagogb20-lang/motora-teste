import{r as i}from"./index-CwulDl8c.js";const t=i("PushNotifications",{});export{t as PushNotifications};
