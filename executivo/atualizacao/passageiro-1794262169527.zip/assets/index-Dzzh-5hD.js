import{r as i}from"./index-DhhCptIC.js";const t=i("PushNotifications",{});export{t as PushNotifications};
