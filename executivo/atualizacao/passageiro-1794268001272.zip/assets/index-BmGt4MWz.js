import{r as i}from"./index-BeGiZRy6.js";const t=i("PushNotifications",{});export{t as PushNotifications};
