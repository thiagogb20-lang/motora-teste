import{r as i}from"./index-DuCNN_8t.js";const t=i("PushNotifications",{});export{t as PushNotifications};
