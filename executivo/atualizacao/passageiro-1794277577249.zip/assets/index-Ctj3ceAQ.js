import{r as i}from"./index-K_EK-9VO.js";const t=i("PushNotifications",{});export{t as PushNotifications};
