import{r as i}from"./index-Dqk325Ck.js";const t=i("PushNotifications",{});export{t as PushNotifications};
