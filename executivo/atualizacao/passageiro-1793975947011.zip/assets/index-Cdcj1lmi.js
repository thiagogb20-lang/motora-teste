import{r as i}from"./index-C5h3Hhuh.js";const t=i("PushNotifications",{});export{t as PushNotifications};
