import{r as i}from"./index-CsFw1-Bv.js";const t=i("PushNotifications",{});export{t as PushNotifications};
