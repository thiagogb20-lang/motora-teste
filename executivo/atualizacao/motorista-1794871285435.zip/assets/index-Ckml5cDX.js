import{r as i}from"./index-DvQK-HuW.js";const t=i("PushNotifications",{});export{t as PushNotifications};
