import{r as i}from"./index-DEAZBx2s.js";const t=i("PushNotifications",{});export{t as PushNotifications};
