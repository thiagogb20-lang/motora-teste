import{r as i}from"./index-CxVqQV7T.js";const t=i("PushNotifications",{});export{t as PushNotifications};
