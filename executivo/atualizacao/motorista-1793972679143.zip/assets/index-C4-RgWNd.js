import{r as i}from"./index-CaFz2sBY.js";const t=i("PushNotifications",{});export{t as PushNotifications};
