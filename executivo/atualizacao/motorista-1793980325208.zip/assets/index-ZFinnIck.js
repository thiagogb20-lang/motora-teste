import{r as i}from"./index-CI2KM-5g.js";const t=i("PushNotifications",{});export{t as PushNotifications};
