import{r as i}from"./index-CAfBpReM.js";const t=i("PushNotifications",{});export{t as PushNotifications};
