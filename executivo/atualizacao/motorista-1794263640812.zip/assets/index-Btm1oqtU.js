import{r as i}from"./index-HxsZKZY_.js";const t=i("PushNotifications",{});export{t as PushNotifications};
