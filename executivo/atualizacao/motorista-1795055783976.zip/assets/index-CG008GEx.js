import{r as i}from"./index-CV_pXSHX.js";const t=i("PushNotifications",{});export{t as PushNotifications};
