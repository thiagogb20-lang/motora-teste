import{r as i}from"./index-DGYPLf-W.js";const t=i("PushNotifications",{});export{t as PushNotifications};
