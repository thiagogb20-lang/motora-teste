import{r as i}from"./index-Cbw2Ij0v.js";const t=i("PushNotifications",{});export{t as PushNotifications};
