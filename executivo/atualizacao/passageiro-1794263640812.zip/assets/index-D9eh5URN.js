import{r as i}from"./index-CLGMqXNo.js";const t=i("PushNotifications",{});export{t as PushNotifications};
