import{r as i}from"./index-CPB9ZMqD.js";const t=i("PushNotifications",{});export{t as PushNotifications};
