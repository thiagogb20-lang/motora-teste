import{r as i}from"./index-iWyflmI3.js";const t=i("PushNotifications",{});export{t as PushNotifications};
