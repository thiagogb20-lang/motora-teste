import{r as i}from"./index-CTvdcYCg.js";const t=i("PushNotifications",{});export{t as PushNotifications};
