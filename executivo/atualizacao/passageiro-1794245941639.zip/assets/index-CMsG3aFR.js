import{r as i}from"./index-DSAQqN1w.js";const t=i("PushNotifications",{});export{t as PushNotifications};
