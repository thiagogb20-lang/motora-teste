import{r as i}from"./index-BvHnK29E.js";const t=i("PushNotifications",{});export{t as PushNotifications};
