import{r as i}from"./index-CAA7mzRQ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
