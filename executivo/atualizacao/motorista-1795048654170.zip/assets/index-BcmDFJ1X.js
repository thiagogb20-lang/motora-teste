import{r as i}from"./index-B9l7fQSo.js";const t=i("PushNotifications",{});export{t as PushNotifications};
