import{r as i}from"./index-4Ysxkz7y.js";const t=i("PushNotifications",{});export{t as PushNotifications};
