import{r as i}from"./index-YKLPr2ju.js";const t=i("PushNotifications",{});export{t as PushNotifications};
