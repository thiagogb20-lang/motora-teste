import{r as i}from"./index-D2xFTol8.js";const t=i("PushNotifications",{});export{t as PushNotifications};
