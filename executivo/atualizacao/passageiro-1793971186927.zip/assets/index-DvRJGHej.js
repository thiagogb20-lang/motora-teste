import{r as i}from"./index-BhM3jJav.js";const t=i("PushNotifications",{});export{t as PushNotifications};
