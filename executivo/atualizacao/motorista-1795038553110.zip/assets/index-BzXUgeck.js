import{r as i}from"./index-BoJhOd4b.js";const t=i("PushNotifications",{});export{t as PushNotifications};
