import{r as i}from"./index-C9fX5zdW.js";const t=i("PushNotifications",{});export{t as PushNotifications};
