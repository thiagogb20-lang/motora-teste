import{r as i}from"./index-DbeCJC73.js";const t=i("PushNotifications",{});export{t as PushNotifications};
