import{r as i}from"./index-BnbUKx4N.js";const t=i("PushNotifications",{});export{t as PushNotifications};
