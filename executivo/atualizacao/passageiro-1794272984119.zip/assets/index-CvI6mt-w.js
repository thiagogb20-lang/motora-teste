import{r as i}from"./index-Cs9qXfrh.js";const t=i("PushNotifications",{});export{t as PushNotifications};
