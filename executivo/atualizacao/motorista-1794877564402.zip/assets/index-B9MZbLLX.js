import{r as i}from"./index-BkjBFbCX.js";const t=i("PushNotifications",{});export{t as PushNotifications};
