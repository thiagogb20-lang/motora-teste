import{r as i}from"./index-oXPDrCK_.js";const t=i("PushNotifications",{});export{t as PushNotifications};
