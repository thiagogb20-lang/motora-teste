import{r as i}from"./index-CTqWyL5A.js";const t=i("PushNotifications",{});export{t as PushNotifications};
