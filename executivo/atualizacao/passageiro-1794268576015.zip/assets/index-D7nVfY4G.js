import{r as i}from"./index-DQRfSBU0.js";const t=i("PushNotifications",{});export{t as PushNotifications};
