import{r as i}from"./index-Ds0GAP9u.js";const t=i("PushNotifications",{});export{t as PushNotifications};
