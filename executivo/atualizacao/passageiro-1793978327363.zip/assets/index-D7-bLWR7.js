import{r as i}from"./index-Jucg2i-L.js";const t=i("PushNotifications",{});export{t as PushNotifications};
