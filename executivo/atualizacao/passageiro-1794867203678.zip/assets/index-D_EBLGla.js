import{r as i}from"./index-BlvmyT0n.js";const t=i("PushNotifications",{});export{t as PushNotifications};
