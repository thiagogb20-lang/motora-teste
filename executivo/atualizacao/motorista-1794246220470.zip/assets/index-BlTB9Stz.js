import{r as i}from"./index-Siwhq8FJ.js";const t=i("PushNotifications",{});export{t as PushNotifications};
