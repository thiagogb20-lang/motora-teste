import{r as i}from"./index-NwITPQfB.js";const t=i("PushNotifications",{});export{t as PushNotifications};
