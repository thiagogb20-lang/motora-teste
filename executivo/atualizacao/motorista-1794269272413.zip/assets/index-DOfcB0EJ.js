import{r as i}from"./index-8gOIli81.js";const t=i("PushNotifications",{});export{t as PushNotifications};
