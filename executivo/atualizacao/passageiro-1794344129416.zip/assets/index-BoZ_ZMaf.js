import{r as i}from"./index-BVWgTgGL.js";const t=i("PushNotifications",{});export{t as PushNotifications};
