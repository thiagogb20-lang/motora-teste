import{r as i}from"./index-Yy-HKVAU.js";const t=i("PushNotifications",{});export{t as PushNotifications};
