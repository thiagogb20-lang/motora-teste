import{r as i}from"./index-C6iebk1m.js";const t=i("PushNotifications",{});export{t as PushNotifications};
