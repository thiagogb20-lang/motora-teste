import{r as i}from"./index-ELkVoHAr.js";const t=i("PushNotifications",{});export{t as PushNotifications};
