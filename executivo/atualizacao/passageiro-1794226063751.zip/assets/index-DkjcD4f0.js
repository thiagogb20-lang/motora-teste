import{r as i}from"./index-DpFkd7-A.js";const t=i("PushNotifications",{});export{t as PushNotifications};
