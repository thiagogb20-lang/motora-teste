import{r as i}from"./index-BsFusjc5.js";const t=i("PushNotifications",{});export{t as PushNotifications};
