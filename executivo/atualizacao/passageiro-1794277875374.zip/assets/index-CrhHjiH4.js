import{r as i}from"./index-Cf5U4tcU.js";const t=i("PushNotifications",{});export{t as PushNotifications};
