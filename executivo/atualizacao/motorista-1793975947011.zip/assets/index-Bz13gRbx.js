import{r as i}from"./index-CSdg7lkS.js";const t=i("PushNotifications",{});export{t as PushNotifications};
