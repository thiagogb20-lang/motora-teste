import{r as i}from"./index-C37aEFhA.js";const t=i("PushNotifications",{});export{t as PushNotifications};
