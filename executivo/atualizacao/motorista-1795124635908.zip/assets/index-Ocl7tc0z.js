import{r as i}from"./index-DBlVZPIw.js";const t=i("PushNotifications",{});export{t as PushNotifications};
