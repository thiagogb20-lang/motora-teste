import{r as i}from"./index-B21lF6uc.js";const t=i("PushNotifications",{});export{t as PushNotifications};
