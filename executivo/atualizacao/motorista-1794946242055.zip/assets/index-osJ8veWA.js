import{r as i}from"./index-DW_DNqJI.js";const t=i("PushNotifications",{});export{t as PushNotifications};
