import{r as i}from"./index-CoZHXT_x.js";const t=i("PushNotifications",{});export{t as PushNotifications};
