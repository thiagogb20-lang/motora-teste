import{r as i}from"./index-BFISWn9m.js";const t=i("PushNotifications",{});export{t as PushNotifications};
