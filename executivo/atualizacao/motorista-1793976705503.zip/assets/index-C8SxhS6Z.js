import{r as i}from"./index-C-udathH.js";const t=i("PushNotifications",{});export{t as PushNotifications};
