import{r as i}from"./index-BL-DuVhz.js";const t=i("PushNotifications",{});export{t as PushNotifications};
