import{r as i}from"./index-DpKtK4nh.js";const t=i("PushNotifications",{});export{t as PushNotifications};
