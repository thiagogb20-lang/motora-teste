import{r as i}from"./index-gh6657ed.js";const t=i("PushNotifications",{});export{t as PushNotifications};
