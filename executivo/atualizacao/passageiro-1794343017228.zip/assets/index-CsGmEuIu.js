import{r as i}from"./index-D0IMyIvw.js";const t=i("PushNotifications",{});export{t as PushNotifications};
