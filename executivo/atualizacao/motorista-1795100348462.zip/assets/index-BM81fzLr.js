import{r as i}from"./index-DFM-LXPb.js";const t=i("PushNotifications",{});export{t as PushNotifications};
