import{r as i}from"./index-B8yFkXy9.js";const t=i("PushNotifications",{});export{t as PushNotifications};
