import{r as i}from"./index-CneH1zTu.js";const t=i("PushNotifications",{});export{t as PushNotifications};
