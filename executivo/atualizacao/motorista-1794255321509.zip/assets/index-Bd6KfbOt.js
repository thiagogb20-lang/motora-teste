import{r as i}from"./index-D-PF9F0h.js";const t=i("PushNotifications",{});export{t as PushNotifications};
