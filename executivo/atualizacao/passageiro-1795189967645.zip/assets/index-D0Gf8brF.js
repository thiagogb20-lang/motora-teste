import{r as i}from"./index-BgSbcyQi.js";const t=i("PushNotifications",{});export{t as PushNotifications};
