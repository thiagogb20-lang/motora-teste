import{r as i}from"./index-DSToGFhF.js";const t=i("PushNotifications",{});export{t as PushNotifications};
