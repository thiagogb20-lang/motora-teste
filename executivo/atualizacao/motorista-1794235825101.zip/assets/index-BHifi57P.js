import{r as i}from"./index-Dlx85YDM.js";const t=i("PushNotifications",{});export{t as PushNotifications};
