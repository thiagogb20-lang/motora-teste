import{r as i}from"./index-BFcMwqfr.js";const t=i("PushNotifications",{});export{t as PushNotifications};
