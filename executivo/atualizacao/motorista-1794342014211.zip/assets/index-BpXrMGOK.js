import{r as i}from"./index-D_DgYBMB.js";const t=i("PushNotifications",{});export{t as PushNotifications};
