import{r as i}from"./index-DypwTjxB.js";const t=i("PushNotifications",{});export{t as PushNotifications};
