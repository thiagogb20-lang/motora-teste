import{r as i}from"./index-CzDPPAbr.js";const t=i("PushNotifications",{});export{t as PushNotifications};
