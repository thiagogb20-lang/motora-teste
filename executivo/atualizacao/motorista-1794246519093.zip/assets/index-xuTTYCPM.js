import{r as i}from"./index-YTw0JwHk.js";const t=i("PushNotifications",{});export{t as PushNotifications};
