import{r as i}from"./index-GdN9LCp8.js";const t=i("PushNotifications",{});export{t as PushNotifications};
