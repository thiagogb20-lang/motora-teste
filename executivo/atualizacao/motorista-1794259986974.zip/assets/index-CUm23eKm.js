import{r as i}from"./index-CqhS6sgh.js";const t=i("PushNotifications",{});export{t as PushNotifications};
