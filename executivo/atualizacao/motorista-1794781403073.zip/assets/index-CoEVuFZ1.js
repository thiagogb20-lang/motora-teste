import{r as i}from"./index-60ybiden.js";const t=i("PushNotifications",{});export{t as PushNotifications};
