import{r as i}from"./index-C_qzPi4R.js";const t=i("PushNotifications",{});export{t as PushNotifications};
