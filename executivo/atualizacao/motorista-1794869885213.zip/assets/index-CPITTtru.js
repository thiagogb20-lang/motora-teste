import{r as i}from"./index-CwmpEg2Y.js";const t=i("PushNotifications",{});export{t as PushNotifications};
