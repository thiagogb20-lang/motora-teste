import{r as i}from"./index-uR1ZP2Om.js";const t=i("PushNotifications",{});export{t as PushNotifications};
