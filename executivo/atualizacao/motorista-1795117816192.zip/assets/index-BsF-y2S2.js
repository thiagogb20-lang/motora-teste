import{r as i}from"./index-CUc4vhaR.js";const t=i("PushNotifications",{});export{t as PushNotifications};
