import{r as i}from"./index-CoCW13Uk.js";const t=i("PushNotifications",{});export{t as PushNotifications};
