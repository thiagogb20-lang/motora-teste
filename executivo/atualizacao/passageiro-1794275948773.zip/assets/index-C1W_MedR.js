import{r as i}from"./index-Cq7n4lN6.js";const t=i("PushNotifications",{});export{t as PushNotifications};
