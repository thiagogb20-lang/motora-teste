import{r as i}from"./index-Ci0N5yug.js";const t=i("PushNotifications",{});export{t as PushNotifications};
