import{r as i}from"./index-De37W0xH.js";const t=i("PushNotifications",{});export{t as PushNotifications};
