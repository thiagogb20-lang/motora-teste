import{r as i}from"./index-DrR09p5z.js";const t=i("PushNotifications",{});export{t as PushNotifications};
