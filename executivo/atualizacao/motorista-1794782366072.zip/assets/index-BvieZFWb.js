import{r as i}from"./index-8xfOjnZP.js";const t=i("PushNotifications",{});export{t as PushNotifications};
