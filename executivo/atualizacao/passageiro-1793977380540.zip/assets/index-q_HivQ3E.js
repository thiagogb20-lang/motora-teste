import{r as i}from"./index-CrZ7Zwzj.js";const t=i("PushNotifications",{});export{t as PushNotifications};
