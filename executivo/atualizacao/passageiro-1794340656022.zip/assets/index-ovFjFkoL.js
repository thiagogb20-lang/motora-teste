import{r as i}from"./index-B25Z-rqf.js";const t=i("PushNotifications",{});export{t as PushNotifications};
