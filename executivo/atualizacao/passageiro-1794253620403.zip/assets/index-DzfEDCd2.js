import{r as i}from"./index-Bu12jRTV.js";const t=i("PushNotifications",{});export{t as PushNotifications};
