import{r as i}from"./index-njq6p4Vo.js";const t=i("PushNotifications",{});export{t as PushNotifications};
