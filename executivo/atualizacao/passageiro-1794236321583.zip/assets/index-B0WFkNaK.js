import{r as i}from"./index-BWzbRzP0.js";const t=i("PushNotifications",{});export{t as PushNotifications};
