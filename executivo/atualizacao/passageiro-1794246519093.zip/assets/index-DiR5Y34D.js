import{r as i}from"./index-Vx7gZClU.js";const t=i("PushNotifications",{});export{t as PushNotifications};
