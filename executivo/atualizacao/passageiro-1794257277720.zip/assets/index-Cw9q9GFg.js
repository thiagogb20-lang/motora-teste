import{r as i}from"./index-B5M2yB90.js";const t=i("PushNotifications",{});export{t as PushNotifications};
