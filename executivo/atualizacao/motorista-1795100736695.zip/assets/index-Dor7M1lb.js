import{r as i}from"./index-G0AdTOvt.js";const t=i("PushNotifications",{});export{t as PushNotifications};
