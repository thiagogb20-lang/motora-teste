import{r as i}from"./index-DozIDBkz.js";const t=i("PushNotifications",{});export{t as PushNotifications};
