import{r as i}from"./index-arMM-GFi.js";const t=i("PushNotifications",{});export{t as PushNotifications};
