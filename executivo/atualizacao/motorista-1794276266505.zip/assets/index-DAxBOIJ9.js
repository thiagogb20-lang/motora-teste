import{r as i}from"./index-jVc1EGkF.js";const t=i("PushNotifications",{});export{t as PushNotifications};
