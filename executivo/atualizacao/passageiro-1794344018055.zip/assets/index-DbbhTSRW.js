import{r as i}from"./index-dbvdS6oo.js";const t=i("PushNotifications",{});export{t as PushNotifications};
