import{r as i}from"./index-DJ1sRWoO.js";const t=i("PushNotifications",{});export{t as PushNotifications};
