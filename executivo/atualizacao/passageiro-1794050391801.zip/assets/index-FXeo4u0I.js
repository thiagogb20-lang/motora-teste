import{r as i}from"./index-DFXj58jo.js";const t=i("PushNotifications",{});export{t as PushNotifications};
