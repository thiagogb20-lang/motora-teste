import{r as i}from"./index-DMa3k_7U.js";const t=i("PushNotifications",{});export{t as PushNotifications};
