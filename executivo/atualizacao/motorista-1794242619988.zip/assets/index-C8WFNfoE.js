import{r as i}from"./index-D7SoU-JW.js";const t=i("PushNotifications",{});export{t as PushNotifications};
