import{r as i}from"./index-VVzBnCa5.js";const t=i("PushNotifications",{});export{t as PushNotifications};
