import{r as i}from"./index-XUKtKPDS.js";const t=i("PushNotifications",{});export{t as PushNotifications};
