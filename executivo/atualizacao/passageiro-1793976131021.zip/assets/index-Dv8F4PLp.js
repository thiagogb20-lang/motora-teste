import{r as i}from"./index-C7qEz1Fm.js";const t=i("PushNotifications",{});export{t as PushNotifications};
