import{r as i}from"./index-DfAgcI0m.js";const t=i("PushNotifications",{});export{t as PushNotifications};
