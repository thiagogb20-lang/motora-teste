import{r as i}from"./index-BskD7sKP.js";const t=i("PushNotifications",{});export{t as PushNotifications};
