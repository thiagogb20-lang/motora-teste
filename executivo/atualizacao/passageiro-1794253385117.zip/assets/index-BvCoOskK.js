import{r as i}from"./index-CZYyouc9.js";const t=i("PushNotifications",{});export{t as PushNotifications};
