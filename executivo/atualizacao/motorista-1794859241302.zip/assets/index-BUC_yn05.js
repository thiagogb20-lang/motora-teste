import{r as i}from"./index-DAWI1bgk.js";const t=i("PushNotifications",{});export{t as PushNotifications};
