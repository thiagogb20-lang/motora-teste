import{r as i}from"./index-DAFNZDuC.js";const t=i("PushNotifications",{});export{t as PushNotifications};
