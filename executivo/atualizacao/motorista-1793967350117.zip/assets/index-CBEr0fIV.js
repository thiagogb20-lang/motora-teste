import{r as i}from"./index-CDo91d93.js";const t=i("PushNotifications",{});export{t as PushNotifications};
