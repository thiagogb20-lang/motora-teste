import{r as i}from"./index-DyrQwwe1.js";const t=i("PushNotifications",{});export{t as PushNotifications};
