import{r as i}from"./index-CGaw6R8r.js";const t=i("PushNotifications",{});export{t as PushNotifications};
