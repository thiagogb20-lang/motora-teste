import{r as i}from"./index-B3fwxlNN.js";const t=i("PushNotifications",{});export{t as PushNotifications};
