import{r as i}from"./index-CgfkulAt.js";const t=i("PushNotifications",{});export{t as PushNotifications};
