import{r as i}from"./index-WYTQ2Gxu.js";const t=i("PushNotifications",{});export{t as PushNotifications};
