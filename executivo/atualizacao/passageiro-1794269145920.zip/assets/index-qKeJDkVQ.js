import{r as i}from"./index-BrEAURSX.js";const t=i("PushNotifications",{});export{t as PushNotifications};
