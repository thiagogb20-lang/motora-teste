import{r as i}from"./index-DUL4qjad.js";const t=i("PushNotifications",{});export{t as PushNotifications};
