import{r as i}from"./index-DT2MGD_F.js";const t=i("PushNotifications",{});export{t as PushNotifications};
