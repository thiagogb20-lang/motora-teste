import{r as i}from"./index-COvd-wVq.js";const t=i("PushNotifications",{});export{t as PushNotifications};
