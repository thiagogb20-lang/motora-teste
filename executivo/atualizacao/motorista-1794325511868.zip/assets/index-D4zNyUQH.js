import{r as i}from"./index-DTE4v9oI.js";const t=i("PushNotifications",{});export{t as PushNotifications};
