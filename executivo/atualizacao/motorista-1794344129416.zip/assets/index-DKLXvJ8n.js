import{r as i}from"./index-DDKG-2gn.js";const t=i("PushNotifications",{});export{t as PushNotifications};
