import{r as i}from"./index-wa3VytII.js";const t=i("PushNotifications",{});export{t as PushNotifications};
