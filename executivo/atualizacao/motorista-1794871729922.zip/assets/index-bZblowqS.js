import{r as i}from"./index-BQUUpwuV.js";const t=i("PushNotifications",{});export{t as PushNotifications};
