import{r as i}from"./index-BmxXsHXR.js";const t=i("PushNotifications",{});export{t as PushNotifications};
