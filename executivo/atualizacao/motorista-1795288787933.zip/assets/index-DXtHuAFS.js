import{r as i}from"./index-XcD2Ug6U.js";const t=i("PushNotifications",{});export{t as PushNotifications};
