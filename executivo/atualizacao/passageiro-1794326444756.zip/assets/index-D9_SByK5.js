import{r as i}from"./index-CyL-koNl.js";const t=i("PushNotifications",{});export{t as PushNotifications};
