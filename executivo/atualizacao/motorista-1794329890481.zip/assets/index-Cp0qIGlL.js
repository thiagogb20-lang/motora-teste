import{r as i}from"./index-zAiId0je.js";const t=i("PushNotifications",{});export{t as PushNotifications};
