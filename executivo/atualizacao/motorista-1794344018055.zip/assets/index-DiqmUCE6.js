import{r as i}from"./index-DbM_pHry.js";const t=i("PushNotifications",{});export{t as PushNotifications};
