import{r as i}from"./index-BtPFQxqG.js";const t=i("PushNotifications",{});export{t as PushNotifications};
