import{r as i}from"./index-BzlEIG9r.js";const t=i("PushNotifications",{});export{t as PushNotifications};
