import{r as i}from"./index-DsoRIYED.js";const t=i("PushNotifications",{});export{t as PushNotifications};
