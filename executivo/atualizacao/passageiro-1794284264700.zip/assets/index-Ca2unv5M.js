import{r as i}from"./index-f5XGDu4t.js";const t=i("PushNotifications",{});export{t as PushNotifications};
