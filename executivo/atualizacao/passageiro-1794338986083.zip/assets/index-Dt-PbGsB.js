import{r as i}from"./index-B4KenDFF.js";const t=i("PushNotifications",{});export{t as PushNotifications};
