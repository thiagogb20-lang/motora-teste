import{r as i}from"./index-C281fTwI.js";const t=i("PushNotifications",{});export{t as PushNotifications};
