import{r as i}from"./index-CkPTIu75.js";const t=i("PushNotifications",{});export{t as PushNotifications};
