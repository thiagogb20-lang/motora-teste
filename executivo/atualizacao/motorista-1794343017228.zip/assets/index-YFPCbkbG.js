import{r as i}from"./index-CWG0pqOn.js";const t=i("PushNotifications",{});export{t as PushNotifications};
