import{r as i}from"./index-4f9j0GqP.js";const t=i("PushNotifications",{});export{t as PushNotifications};
