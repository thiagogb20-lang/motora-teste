import{r as i}from"./index-NHK6Z-WY.js";const t=i("PushNotifications",{});export{t as PushNotifications};
