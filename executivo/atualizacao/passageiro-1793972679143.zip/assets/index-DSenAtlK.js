import{r as i}from"./index-CZCoWChd.js";const t=i("PushNotifications",{});export{t as PushNotifications};
