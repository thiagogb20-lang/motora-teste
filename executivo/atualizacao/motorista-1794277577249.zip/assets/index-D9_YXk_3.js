import{r as i}from"./index-DMWypxBF.js";const t=i("PushNotifications",{});export{t as PushNotifications};
