import{r as i}from"./index-B_DDR-rG.js";const t=i("PushNotifications",{});export{t as PushNotifications};
