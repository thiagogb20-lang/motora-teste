import{r as i}from"./index-D7tW1t4W.js";const t=i("PushNotifications",{});export{t as PushNotifications};
