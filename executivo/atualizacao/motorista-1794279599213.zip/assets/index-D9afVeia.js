import{r as i}from"./index-D2_9IFqX.js";const t=i("PushNotifications",{});export{t as PushNotifications};
