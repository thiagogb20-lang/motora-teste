import{r as i}from"./index-CC-03kIl.js";const t=i("PushNotifications",{});export{t as PushNotifications};
