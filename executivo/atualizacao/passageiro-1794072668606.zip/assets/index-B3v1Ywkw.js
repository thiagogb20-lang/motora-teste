import{r as i}from"./index-Clbv704A.js";const t=i("PushNotifications",{});export{t as PushNotifications};
