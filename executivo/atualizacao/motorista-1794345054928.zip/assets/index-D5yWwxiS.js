import{r as i}from"./index-DSyB772h.js";const t=i("PushNotifications",{});export{t as PushNotifications};
