import{r as i}from"./index-C81cUMuE.js";const t=i("PushNotifications",{});export{t as PushNotifications};
