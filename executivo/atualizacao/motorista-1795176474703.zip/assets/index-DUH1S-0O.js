import{r as i}from"./index-Ckc-I3yy.js";const t=i("PushNotifications",{});export{t as PushNotifications};
