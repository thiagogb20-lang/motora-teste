import{r as i}from"./index-Cfkd0TwW.js";const t=i("PushNotifications",{});export{t as PushNotifications};
