import{r as i}from"./index-DUTOmiTk.js";const t=i("PushNotifications",{});export{t as PushNotifications};
