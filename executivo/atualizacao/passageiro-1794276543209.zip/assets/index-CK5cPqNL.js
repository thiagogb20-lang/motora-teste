import{r as i}from"./index-BRWjUb2J.js";const t=i("PushNotifications",{});export{t as PushNotifications};
