import{r as i}from"./index-q1jhcjlC.js";const t=i("PushNotifications",{});export{t as PushNotifications};
