import{r as i}from"./index-Bn5f_j4u.js";const t=i("PushNotifications",{});export{t as PushNotifications};
