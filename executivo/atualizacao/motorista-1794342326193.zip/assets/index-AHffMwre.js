import{r as i}from"./index-BJ-woRMO.js";const t=i("PushNotifications",{});export{t as PushNotifications};
