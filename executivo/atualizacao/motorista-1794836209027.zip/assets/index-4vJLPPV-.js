import{r as i}from"./index-BiOSbIca.js";const t=i("PushNotifications",{});export{t as PushNotifications};
