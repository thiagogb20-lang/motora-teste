import{r as i}from"./index-IyWod7M8.js";const t=i("PushNotifications",{});export{t as PushNotifications};
