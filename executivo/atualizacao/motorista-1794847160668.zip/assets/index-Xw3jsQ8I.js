import{r as i}from"./index-C6rliCMF.js";const t=i("PushNotifications",{});export{t as PushNotifications};
