import{r as i}from"./index-Cj_cXUon.js";const t=i("PushNotifications",{});export{t as PushNotifications};
