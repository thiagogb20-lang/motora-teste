import{r as i}from"./index-C0VvxHSU.js";const t=i("PushNotifications",{});export{t as PushNotifications};
