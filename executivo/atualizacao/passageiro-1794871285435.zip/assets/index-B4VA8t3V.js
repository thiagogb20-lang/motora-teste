import{r as i}from"./index-BbPkzPOU.js";const t=i("PushNotifications",{});export{t as PushNotifications};
