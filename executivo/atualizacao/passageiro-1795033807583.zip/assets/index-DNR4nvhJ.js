import{r as i}from"./index-D1YVJqGv.js";const t=i("PushNotifications",{});export{t as PushNotifications};
