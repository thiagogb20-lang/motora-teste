import{r as i}from"./index-NC7UwVCO.js";const t=i("PushNotifications",{});export{t as PushNotifications};
