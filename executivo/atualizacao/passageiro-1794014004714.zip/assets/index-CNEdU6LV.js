import{r as i}from"./index-CTO6KkYk.js";const t=i("PushNotifications",{});export{t as PushNotifications};
