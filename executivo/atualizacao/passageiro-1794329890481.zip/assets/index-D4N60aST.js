import{r as i}from"./index-DxAWVmTo.js";const t=i("PushNotifications",{});export{t as PushNotifications};
