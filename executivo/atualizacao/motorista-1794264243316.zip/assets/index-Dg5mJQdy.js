import{r as i}from"./index-DuTjQafy.js";const t=i("PushNotifications",{});export{t as PushNotifications};
