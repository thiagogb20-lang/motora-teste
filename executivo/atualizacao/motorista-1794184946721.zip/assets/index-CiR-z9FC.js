import{r as i}from"./index-Dpg_941X.js";const t=i("PushNotifications",{});export{t as PushNotifications};
