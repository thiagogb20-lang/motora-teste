import{r as i}from"./index-DKz-D-Cv.js";const t=i("PushNotifications",{});export{t as PushNotifications};
