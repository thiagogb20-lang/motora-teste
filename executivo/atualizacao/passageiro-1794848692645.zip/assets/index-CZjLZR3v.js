import{r as i}from"./index-OJb1Ktz3.js";const t=i("PushNotifications",{});export{t as PushNotifications};
