import{r as i}from"./index-B5FgLm-Q.js";const t=i("PushNotifications",{});export{t as PushNotifications};
