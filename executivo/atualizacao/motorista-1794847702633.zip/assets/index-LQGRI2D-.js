import{r as i}from"./index-DL-GOtc8.js";const t=i("PushNotifications",{});export{t as PushNotifications};
