import{r as i}from"./index-CBJ24bsX.js";const t=i("PushNotifications",{});export{t as PushNotifications};
