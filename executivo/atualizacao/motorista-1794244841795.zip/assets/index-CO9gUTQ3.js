import{r as i}from"./index-Nw56tUvV.js";const t=i("PushNotifications",{});export{t as PushNotifications};
