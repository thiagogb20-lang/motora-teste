import{r as i}from"./index-v-8mLROy.js";const t=i("PushNotifications",{});export{t as PushNotifications};
