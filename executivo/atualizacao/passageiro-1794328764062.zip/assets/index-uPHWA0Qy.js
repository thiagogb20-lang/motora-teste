import{r as i}from"./index-DZRn-kMw.js";const t=i("PushNotifications",{});export{t as PushNotifications};
