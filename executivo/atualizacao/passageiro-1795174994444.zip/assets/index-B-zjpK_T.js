import{r as i}from"./index-DBWojvQ8.js";const t=i("PushNotifications",{});export{t as PushNotifications};
