import{r as i}from"./index-B_YJ3zZ4.js";const t=i("PushNotifications",{});export{t as PushNotifications};
