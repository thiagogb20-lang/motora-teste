import{r as i}from"./index-GEydUBcS.js";const t=i("PushNotifications",{});export{t as PushNotifications};
