import{r as i}from"./index-pDieZPpp.js";const t=i("PushNotifications",{});export{t as PushNotifications};
