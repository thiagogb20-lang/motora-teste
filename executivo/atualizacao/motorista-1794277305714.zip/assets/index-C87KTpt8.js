import{r as i}from"./index-B0zjuyF4.js";const t=i("PushNotifications",{});export{t as PushNotifications};
