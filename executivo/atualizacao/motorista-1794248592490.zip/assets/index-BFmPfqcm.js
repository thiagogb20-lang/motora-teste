import{r as i}from"./index-B5ECQCjt.js";const t=i("PushNotifications",{});export{t as PushNotifications};
